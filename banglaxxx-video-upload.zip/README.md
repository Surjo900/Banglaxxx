# Banglaxxx Video Upload Site

A simple Node.js & Express application to upload and stream videos.

## Setup

1. Clone the repository:

```bash
git clone https://github.com/yourusername/banglaxxx-video-upload.git
cd banglaxxx-video-upload
```

2. Install dependencies:

```bash
npm install
```

3. Start the server:

```bash
npm start
```

4. Open your browser and visit:

- http://localhost:3000 - Video Gallery
- http://localhost:3000/upload - Upload Videos

## Tech Stack

- Node.js
- Express
- Multer (for file upload)
- HTML5 Video Player